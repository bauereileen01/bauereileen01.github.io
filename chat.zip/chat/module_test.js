var mymod = require('./mymod');

console.log(mymod.something());
