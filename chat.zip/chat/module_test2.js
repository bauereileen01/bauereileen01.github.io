var User = require("./user");

var u = new User('fred');
console.log(u.name);
