function User(name) {
  this.name = name;
}

module.exports = User;
