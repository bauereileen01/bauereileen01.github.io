exports.something = function() { return 10 };
